/*! Cornerstone Components 0.6.2 - MIT licensed. See LICENSE.md and NOTICE. */
import {
  A
} from "./chunk.B2T6AD2P.js";

// ../../node_modules/lit-html/directives/if-defined.js
var o = (o2) => o2 ?? A;

export {
  o
};
/*! Bundled license information:

lit-html/directives/if-defined.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
