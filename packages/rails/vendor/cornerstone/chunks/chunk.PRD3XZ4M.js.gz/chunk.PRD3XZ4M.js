/*! Cornerstone Components 0.6.2 - MIT licensed. See LICENSE.md and NOTICE. */
import {
  registerTranslation
} from "./chunk.FFJLVZKJ.js";

// src/translations/en.ts
var translation = {
  $code: "en",
  $name: "English",
  $dir: "ltr",
  am: "AM",
  autosizeColumn: "Autosize column",
  captions: "Captions",
  carousel: "Carousel",
  chooseDate: "Choose date",
  chooseDecade: "Choose decade",
  chooseMonth: "Choose month",
  chooseTime: "Choose time",
  chooseYear: "Choose year",
  clearEntry: "Clear entry",
  clearFilter: "Clear filter",
  clearSort: "Clear sort",
  close: "Close",
  closeCalendar: "Close calendar",
  closeTimeInput: "Close time picker",
  collapseRow: "Collapse row",
  columnMenu: "Column options",
  columnMovedToPosition: (label, position, total) => `${label} moved to position ${position} of ${total}`,
  columns: "Columns",
  compactPageXOfY: (page, total) => `${page} of ${total}`,
  copied: "Copied",
  copy: "Copy",
  createOption: (value) => `Create "${value}"`,
  currentlyPlaying: "currently playing",
  currentValue: "Current value",
  date: "Date",
  datePickerKeyboardHelp: "Use arrow keys to change values; press Alt+Down Arrow to open the calendar.",
  day: "Day",
  dayPeriod: "AM/PM",
  decrement: "Decrement",
  deselectAllRows: "Deselect all rows",
  dropFileHere: "Drop file here or click to browse",
  dropFilesHere: "Drop files here or click to browse",
  empty: "Empty",
  endDate: "End date",
  enterFullscreen: "Enter fullscreen",
  error: "Error",
  exitFullscreen: "Exit fullscreen",
  expandRow: "Expand row",
  filterByColumn: (label) => `Filter by ${label}`,
  filterFrom: "From",
  filterMax: "Max",
  filterMin: "Min",
  filterTo: "To",
  firstPage: "First page",
  goToSlide: (slide, count) => `Go to slide ${slide} of ${count}`,
  hideColumn: "Hide column",
  hidePassword: "Hide password",
  hour: "Hour",
  incompleteDate: "Enter a valid date.",
  increment: "Increment",
  jumpBackwardX: (count) => `Jump back ${count} pages`,
  jumpForwardX: (count) => `Jump forward ${count} pages`,
  lastPage: "Last page",
  loading: "Loading",
  minute: "Minute",
  month: "Month",
  moreOptions: "More Options",
  mute: "Mute",
  nextDecade: "Next decade",
  nextMonth: "Next month",
  nextPage: "Next page",
  nextSlide: "Next slide",
  nextVideo: "Next Video",
  nextYear: "Next year",
  noData: "No data",
  noResults: "No matching results",
  now: "Now",
  numCharacters: (num) => {
    if (num === 1) {
      return "1 character";
    }
    return `${num} characters`;
  },
  numCharactersRemaining: (num) => {
    if (num === 1) {
      return "1 character remaining";
    }
    return `${num} characters remaining`;
  },
  numOptionsSelected: (num) => {
    if (num === 0) {
      return "No options selected";
    }
    if (num === 1) {
      return "1 option selected";
    }
    return `${num} options selected`;
  },
  numRowsCopied: (num) => num === 1 ? "1 row copied" : `${num} rows copied`,
  numRowsSelected: (num) => num === 1 ? "1 row selected" : `${num} rows selected`,
  pageXOfY: (page, total) => `Page ${page} of ${total}`,
  pagination: "Pagination",
  pause: "Pause",
  pauseAnimation: "Pause animation",
  pictureInPicture: "Picture in picture",
  pinLeft: "Pin left",
  pinRight: "Pin right",
  play: "Play",
  playAnimation: "Play animation",
  playbackSpeed: "Playback speed",
  playlist: "Playlist",
  pm: "PM",
  previousDecade: "Previous decade",
  previousMonth: "Previous month",
  previousPage: "Previous page",
  previousSlide: "Previous slide",
  previousVideo: "Previous video",
  previousYear: "Previous year",
  progress: "Progress",
  rangeTooLong: (max) => {
    if (max === 1) {
      return "Select a range no longer than 1 day";
    }
    return `Select a range no longer than ${max} days`;
  },
  rangeTooShort: (min) => {
    if (min === 1) {
      return "Select a range at least 1 day long";
    }
    return `Select a range at least ${min} days long`;
  },
  readonly: "Read-only",
  remove: "Remove",
  resetColumns: "Reset columns",
  resize: "Resize",
  resizeColumn: "Resize column",
  rowsPerPage: "Rows per page",
  scrollableRegion: "Scrollable region",
  scrollToEnd: "Scroll to end",
  scrollToStart: "Scroll to start",
  search: "Search",
  second: "Second",
  seek: "Seek",
  seekProgress: (current, duration) => `${current} of ${duration}`,
  selectAColorFromTheScreen: "Select a color from the screen",
  selectAllRows: "Select all rows",
  selected: "Selected",
  selectedDateLabel: (date) => `Selected: ${date}`,
  selectedRangeLabel: (range) => `Selected range: ${range}`,
  selectGroup: "Select group",
  selectionCleared: "Selection cleared",
  selectRow: "Select row",
  showingNofMRows: (shown, total) => `Showing ${shown} of ${total} rows`,
  showingXtoYofZ: (start, end, total) => `${start}\u2013${end} of ${total}`,
  showPassword: "Show password",
  slideNum: (slide) => `Slide ${slide}`,
  sortAscending: "Sort ascending",
  sortColumn: "Sort column",
  sortDescending: "Sort descending",
  startDate: "Start date",
  time: "Time",
  timeInputKeyboardHelp: "Use arrow keys to change values; press Alt+Down Arrow to open the time picker.",
  today: "Today",
  toggleColorFormat: "Toggle color format",
  unmute: "Unmute",
  unpin: "Unpin",
  unpinColumn: "Unpin column",
  videoPlayer: "Video player",
  volume: "Volume",
  year: "Year",
  zoomIn: "Zoom in",
  zoomOut: "Zoom out"
};
registerTranslation(translation);
var en_default = translation;

export {
  en_default
};
