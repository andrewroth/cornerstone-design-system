/*! Cornerstone Components 0.6.2 - MIT licensed. See LICENSE.md and NOTICE. */
import {
  carousel_item_styles_default
} from "../../chunks/chunk.HLCWYOAF.js";
import "../../chunks/chunk.CRKHH5GL.js";
import "../../chunks/chunk.B2T6AD2P.js";
import "../../chunks/chunk.QQCENPXN.js";
export {
  carousel_item_styles_default as default
};
