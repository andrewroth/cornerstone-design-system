/*! Cornerstone Components 0.6.2 - MIT licensed. See LICENSE.md and NOTICE. */
import "../chunks/chunk.QUVFD4CZ.js";
import "../chunks/chunk.PRD3XZ4M.js";
import {
  registerTranslation
} from "../chunks/chunk.FFJLVZKJ.js";
import "../chunks/chunk.QQCENPXN.js";

// src/translations/hu.ts
var translation = {
  $code: "hu",
  $name: "Magyar",
  $dir: "ltr",
  am: "de.",
  autosizeColumn: "Oszlop m\xE9retez\xE9se a tartalomhoz",
  captions: "Feliratok",
  carousel: "K\xF6rhinta",
  chooseDate: "D\xE1tum kiv\xE1laszt\xE1sa",
  chooseDecade: "\xC9vtized kiv\xE1laszt\xE1sa",
  chooseMonth: "H\xF3nap kiv\xE1laszt\xE1sa",
  chooseTime: "Id\u0151 kiv\xE1laszt\xE1sa",
  chooseYear: "\xC9v kiv\xE1laszt\xE1sa",
  clearEntry: "Bejegyz\xE9s t\xF6rl\xE9se",
  clearFilter: "Sz\u0171r\u0151 t\xF6rl\xE9se",
  clearSort: "Rendez\xE9s t\xF6rl\xE9se",
  close: "Bez\xE1r\xE1s",
  closeCalendar: "Napt\xE1r bez\xE1r\xE1sa",
  closeTimeInput: "Id\u0151v\xE1laszt\xF3 bez\xE1r\xE1sa",
  collapseRow: "Sor \xF6sszecsuk\xE1sa",
  columnMenu: "Oszlop be\xE1ll\xEDt\xE1sai",
  columnMovedToPosition: (label, position, total) => `${label} \xE1thelyezve a(z) ${total}/${position}. poz\xEDci\xF3ba`,
  columns: "Oszlopok",
  compactPageXOfY: (page, total) => `${total}/${page}`,
  copied: "M\xE1solva",
  copy: "M\xE1sol\xE1s",
  createOption: (value) => `\u201E${value}" l\xE9trehoz\xE1sa`,
  currentlyPlaying: "\xE9ppen j\xE1tszik",
  currentValue: "Aktu\xE1lis \xE9rt\xE9k",
  date: "D\xE1tum",
  datePickerKeyboardHelp: "A ny\xEDlbillenty\u0171kkel m\xF3dos\xEDthatja az \xE9rt\xE9keket; az Alt+Lefel\xE9 ny\xEDl megnyitja a napt\xE1rat.",
  day: "Nap",
  dayPeriod: "de./du.",
  decrement: "Cs\xF6kkent\xE9s",
  deselectAllRows: "\xD6sszes sor kijel\xF6l\xE9s\xE9nek megsz\xFCntet\xE9se",
  dropFileHere: "Drop file here or click to browse",
  dropFilesHere: "Drop files here or click to browse",
  empty: "\xDCres",
  endDate: "Befejez\u0151 d\xE1tum",
  enterFullscreen: "Teljes k\xE9perny\u0151",
  error: "Hiba",
  exitFullscreen: "Kil\xE9p\xE9s a teljes k\xE9perny\u0151b\u0151l",
  expandRow: "Sor kibont\xE1sa",
  filterByColumn: (label) => `Sz\u0171r\xE9s a k\xF6vetkez\u0151 szerint: ${label}`,
  filterFrom: "Ett\u0151l",
  filterMax: "Max.",
  filterMin: "Min.",
  filterTo: "Eddig",
  firstPage: "Els\u0151 oldal",
  goToSlide: (slide, count) => `Ugr\xE1s a ${count}/${slide}. di\xE1ra`,
  hideColumn: "Oszlop elrejt\xE9se",
  hidePassword: "Jelsz\xF3 elrejt\xE9se",
  hour: "\xD3ra",
  incompleteDate: "Adjon meg egy \xE9rv\xE9nyes d\xE1tumot.",
  increment: "N\xF6vel\xE9s",
  jumpBackwardX: (count) => `Ugr\xE1s ${count} oldallal vissza`,
  jumpForwardX: (count) => `Ugr\xE1s ${count} oldallal el\u0151re`,
  lastPage: "Utols\xF3 oldal",
  loading: "Bet\xF6lt\xE9s",
  minute: "Perc",
  month: "H\xF3nap",
  moreOptions: "Tov\xE1bbi lehet\u0151s\xE9gek",
  mute: "Eln\xE9m\xEDt\xE1s",
  nextDecade: "K\xF6vetkez\u0151 \xE9vtized",
  nextMonth: "K\xF6vetkez\u0151 h\xF3nap",
  nextPage: "K\xF6vetkez\u0151 oldal",
  nextSlide: "K\xF6vetkez\u0151 dia",
  nextVideo: "K\xF6vetkez\u0151 vide\xF3",
  nextYear: "K\xF6vetkez\u0151 \xE9v",
  noData: "Nincs adat",
  noResults: "Nincs egyez\u0151 tal\xE1lat",
  now: "Most",
  numCharacters: (num) => {
    if (num === 1) {
      return "1 karakter";
    }
    return `${num} karakter`;
  },
  numCharactersRemaining: (num) => {
    if (num === 1) {
      return "1 karakter maradt";
    }
    return `${num} karakter maradt`;
  },
  numOptionsSelected: (num) => {
    if (num === 0) {
      return "Nincsenek kiv\xE1lasztva opci\xF3k";
    }
    if (num === 1) {
      return "1 lehet\u0151s\xE9g kiv\xE1lasztva";
    }
    return `${num} lehet\u0151s\xE9g kiv\xE1lasztva`;
  },
  numRowsCopied: (num) => num === 1 ? "1 sor m\xE1solva" : `${num} sor m\xE1solva`,
  numRowsSelected: (num) => num === 1 ? "1 sor kiv\xE1lasztva" : `${num} sor kiv\xE1lasztva`,
  pageXOfY: (page, total) => `${total}/${page}. oldal`,
  pagination: "Lapoz\xE1s",
  pause: "Sz\xFCnet",
  pauseAnimation: "Anim\xE1ci\xF3 sz\xFCneteltet\xE9se",
  pictureInPicture: "K\xE9p a k\xE9pben",
  pinLeft: "R\xF6gz\xEDt\xE9s balra",
  pinRight: "R\xF6gz\xEDt\xE9s jobbra",
  play: "Lej\xE1tsz\xE1s",
  playAnimation: "Anim\xE1ci\xF3 lej\xE1tsz\xE1sa",
  playbackSpeed: "Lej\xE1tsz\xE1si sebess\xE9g",
  playlist: "Lej\xE1tsz\xE1si lista",
  pm: "du.",
  previousDecade: "El\u0151z\u0151 \xE9vtized",
  previousMonth: "El\u0151z\u0151 h\xF3nap",
  previousPage: "El\u0151z\u0151 oldal",
  previousSlide: "El\u0151z\u0151 dia",
  previousVideo: "El\u0151z\u0151 vide\xF3",
  previousYear: "El\u0151z\u0151 \xE9v",
  progress: "Folyamat",
  rangeTooLong: (max) => {
    if (max === 1) {
      return "V\xE1lasszon legfeljebb 1 napos tartom\xE1nyt";
    }
    return `V\xE1lasszon legfeljebb ${max} napos tartom\xE1nyt`;
  },
  rangeTooShort: (min) => {
    if (min === 1) {
      return "V\xE1lasszon legal\xE1bb 1 napos tartom\xE1nyt";
    }
    return `V\xE1lasszon legal\xE1bb ${min} napos tartom\xE1nyt`;
  },
  readonly: "Csak olvashat\xF3",
  remove: "Elt\xE1vol\xEDt\xE1s",
  resetColumns: "Oszlopok vissza\xE1ll\xEDt\xE1sa",
  resize: "\xC1tm\xE9retez\xE9s",
  resizeColumn: "Oszlop \xE1tm\xE9retez\xE9se",
  rowsPerPage: "Sorok oldalank\xE9nt",
  scrollableRegion: "G\xF6rgethet\u0151 ter\xFClet",
  scrollToEnd: "G\xF6rgessen a v\xE9g\xE9re",
  scrollToStart: "G\xF6rgessen az elej\xE9re",
  search: "Keres\xE9s",
  second: "M\xE1sodperc",
  seek: "Keres\xE9s",
  seekProgress: (current, duration) => `${current} / ${duration}`,
  selectAColorFromTheScreen: "Sz\xEDn v\xE1laszt\xE1sa a k\xE9perny\u0151r\u0151l",
  selectAllRows: "\xD6sszes sor kijel\xF6l\xE9se",
  selected: "Kiv\xE1lasztva",
  selectedDateLabel: (date) => `Kiv\xE1lasztva: ${date}`,
  selectedRangeLabel: (range) => `Kiv\xE1lasztott tartom\xE1ny: ${range}`,
  selectGroup: "Csoport kijel\xF6l\xE9se",
  selectionCleared: "Kijel\xF6l\xE9s t\xF6r\xF6lve",
  selectRow: "Sor kijel\xF6l\xE9se",
  showingNofMRows: (shown, total) => `${total} sorb\xF3l ${shown} megjelen\xEDtve`,
  showingXtoYofZ: (start, end, total) => `${start}\u2013${end} / ${total}`,
  showPassword: "Jelsz\xF3 megjelen\xEDt\xE9se",
  slideNum: (slide) => `${slide}. dia`,
  sortAscending: "N\xF6vekv\u0151 rendez\xE9s",
  sortColumn: "Oszlop rendez\xE9se",
  sortDescending: "Cs\xF6kken\u0151 rendez\xE9s",
  startDate: "Kezd\u0151 d\xE1tum",
  time: "Id\u0151",
  timeInputKeyboardHelp: "A ny\xEDlbillenty\u0171kkel m\xF3dos\xEDthatja az \xE9rt\xE9keket; az Alt+Lefel\xE9 ny\xEDl megnyitja az id\u0151v\xE1laszt\xF3t.",
  today: "Ma",
  toggleColorFormat: "Sz\xEDnform\xE1tum v\xE1ltoztat\xE1sa",
  unmute: "Eln\xE9m\xEDt\xE1s felold\xE1sa",
  unpin: "R\xF6gz\xEDt\xE9s felold\xE1sa",
  unpinColumn: "Oszlop r\xF6gz\xEDt\xE9s\xE9nek felold\xE1sa",
  videoPlayer: "Vide\xF3lej\xE1tsz\xF3",
  volume: "Hanger\u0151",
  year: "\xC9v",
  zoomIn: "Nagy\xEDt\xE1s",
  zoomOut: "Kicsiny\xEDt\xE9s"
};
registerTranslation(translation);
var hu_default = translation;
export {
  hu_default as default
};
