/*! Cornerstone Components 0.6.2 - MIT licensed. See LICENSE.md and NOTICE. */
import {
  registerTranslation
} from "../chunks/chunk.FFJLVZKJ.js";
import "../chunks/chunk.QQCENPXN.js";

// src/translations/id.ts
var translation = {
  $code: "id",
  $name: "Bahasa Indonesia",
  $dir: "ltr",
  am: "AM",
  autosizeColumn: "Sesuaikan ukuran kolom",
  captions: "Teks",
  carousel: "Karousel",
  chooseDate: "Pilih tanggal",
  chooseDecade: "Pilih dekade",
  chooseMonth: "Pilih bulan",
  chooseTime: "Pilih waktu",
  chooseYear: "Pilih tahun",
  clearEntry: "Hapus entri",
  clearFilter: "Hapus filter",
  clearSort: "Hapus pengurutan",
  close: "Tutup",
  closeCalendar: "Tutup kalender",
  closeTimeInput: "Tutup pemilih waktu",
  collapseRow: "Ciutkan baris",
  columnMenu: "Opsi kolom",
  columnMovedToPosition: (label, position, total) => `${label} dipindahkan ke posisi ${position} dari ${total}`,
  columns: "Kolom",
  compactPageXOfY: (page, total) => `${page} dari ${total}`,
  copied: "Disalin",
  copy: "Salin",
  createOption: (value) => `Buat "${value}"`,
  currentlyPlaying: "sedang diputar",
  currentValue: "Nilai saat ini",
  date: "Tanggal",
  datePickerKeyboardHelp: "Gunakan tombol panah untuk mengubah nilai; tekan Alt+Panah Bawah untuk membuka kalender.",
  day: "Hari",
  dayPeriod: "AM/PM",
  decrement: "Kurangi",
  deselectAllRows: "Batalkan pilihan semua baris",
  dropFileHere: "Drop file here or click to browse",
  dropFilesHere: "Drop files here or click to browse",
  empty: "Kosong",
  endDate: "Tanggal akhir",
  enterFullscreen: "Masuk layar penuh",
  error: "Kesalahan",
  exitFullscreen: "Keluar layar penuh",
  expandRow: "Perluas baris",
  filterByColumn: (label) => `Filter berdasarkan ${label}`,
  filterFrom: "Dari",
  filterMax: "Maks",
  filterMin: "Min",
  filterTo: "Hingga",
  firstPage: "Halaman pertama",
  goToSlide: (slide, count) => `Pergi ke slide ${slide} dari ${count}`,
  hideColumn: "Sembunyikan kolom",
  hidePassword: "Sembunyikan sandi",
  hour: "Jam",
  incompleteDate: "Masukkan tanggal yang valid.",
  increment: "Tambah",
  jumpBackwardX: (count) => `Mundur ${count} halaman`,
  jumpForwardX: (count) => `Maju ${count} halaman`,
  lastPage: "Halaman terakhir",
  loading: "Memuat",
  minute: "Menit",
  month: "Bulan",
  moreOptions: "Lebih banyak opsi",
  mute: "Bisukan",
  nextDecade: "Dekade berikutnya",
  nextMonth: "Bulan berikutnya",
  nextPage: "Halaman berikutnya",
  nextSlide: "Slide berikutnya",
  nextVideo: "Video berikutnya",
  nextYear: "Tahun berikutnya",
  noData: "Tidak ada data",
  noResults: "Tidak ada hasil yang cocok",
  now: "Sekarang",
  numCharacters: (num) => {
    if (num === 1) {
      return "1 karakter";
    }
    return `${num} karakter`;
  },
  numCharactersRemaining: (num) => {
    if (num === 1) {
      return "1 karakter tersisa";
    }
    return `${num} karakter tersisa`;
  },
  numOptionsSelected: (num) => {
    if (num === 0) {
      return "Tidak ada opsi yang dipilih";
    }
    if (num === 1) {
      return "1 opsi yang dipilih";
    }
    return `${num} opsi yang dipilih`;
  },
  numRowsCopied: (num) => `${num} baris disalin`,
  numRowsSelected: (num) => `${num} baris dipilih`,
  pageXOfY: (page, total) => `Halaman ${page} dari ${total}`,
  pagination: "Penomoran halaman",
  pause: "Jeda",
  pauseAnimation: "Jeda animasi",
  pictureInPicture: "Gambar dalam gambar",
  pinLeft: "Sematkan ke kiri",
  pinRight: "Sematkan ke kanan",
  play: "Putar",
  playAnimation: "Putar animasi",
  playbackSpeed: "Kecepatan putar",
  playlist: "Daftar putar",
  pm: "PM",
  previousDecade: "Dekade sebelumnya",
  previousMonth: "Bulan sebelumnya",
  previousPage: "Halaman sebelumnya",
  previousSlide: "Slide sebelumnya",
  previousVideo: "Video sebelumnya",
  previousYear: "Tahun sebelumnya",
  progress: "Kemajuan",
  rangeTooLong: (max) => {
    if (max === 1) {
      return "Pilih rentang tidak lebih dari 1 hari";
    }
    return `Pilih rentang tidak lebih dari ${max} hari`;
  },
  rangeTooShort: (min) => {
    if (min === 1) {
      return "Pilih rentang minimal 1 hari";
    }
    return `Pilih rentang minimal ${min} hari`;
  },
  readonly: "Hanya-baca",
  remove: "Hapus",
  resetColumns: "Atur ulang kolom",
  resize: "Ubah ukuran",
  resizeColumn: "Ubah ukuran kolom",
  rowsPerPage: "Baris per halaman",
  scrollableRegion: "Area yang dapat digulir",
  scrollToEnd: "Gulir ke akhir",
  scrollToStart: "Gulir ke awal",
  search: "Cari",
  second: "Detik",
  seek: "Cari",
  seekProgress: (current, duration) => `${current} dari ${duration}`,
  selectAColorFromTheScreen: "Pilih warna dari layar",
  selectAllRows: "Pilih semua baris",
  selected: "Dipilih",
  selectedDateLabel: (date) => `Dipilih: ${date}`,
  selectedRangeLabel: (range) => `Rentang yang dipilih: ${range}`,
  selectGroup: "Pilih grup",
  selectionCleared: "Pilihan dihapus",
  selectRow: "Pilih baris",
  showingNofMRows: (shown, total) => `Menampilkan ${shown} dari ${total} baris`,
  showingXtoYofZ: (start, end, total) => `${start}\u2013${end} dari ${total}`,
  showPassword: "Tampilkan sandi",
  slideNum: (slide) => `Slide ${slide}`,
  sortAscending: "Urutkan menaik",
  sortColumn: "Urutkan kolom",
  sortDescending: "Urutkan menurun",
  startDate: "Tanggal mulai",
  time: "Waktu",
  timeInputKeyboardHelp: "Gunakan tombol panah untuk mengubah nilai; tekan Alt+Panah Bawah untuk membuka pemilih waktu.",
  today: "Hari ini",
  toggleColorFormat: "Beralih format warna",
  unmute: "Aktifkan suara",
  unpin: "Lepas sematan",
  unpinColumn: "Lepas sematan kolom",
  videoPlayer: "Pemutar video",
  volume: "Volume",
  year: "Tahun",
  zoomIn: "Perbesar",
  zoomOut: "Perkecil"
};
registerTranslation(translation);
var id_default = translation;
export {
  id_default as default
};
