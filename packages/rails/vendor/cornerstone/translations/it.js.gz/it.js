/*! Cornerstone Components 0.6.2 - MIT licensed. See LICENSE.md and NOTICE. */
import {
  registerTranslation
} from "../chunks/chunk.FFJLVZKJ.js";
import "../chunks/chunk.QQCENPXN.js";

// src/translations/it.ts
var translation = {
  $code: "it",
  $name: "Italiano",
  $dir: "ltr",
  am: "AM",
  autosizeColumn: "Adatta colonna al contenuto",
  captions: "Sottotitoli",
  carousel: "Carosello",
  chooseDate: "Scegli data",
  chooseDecade: "Scegli decennio",
  chooseMonth: "Scegli mese",
  chooseTime: "Scegli ora",
  chooseYear: "Scegli anno",
  clearEntry: "Cancella inserimento",
  clearFilter: "Annulla filtro",
  clearSort: "Annulla ordinamento",
  close: "Chiudi",
  closeCalendar: "Chiudi calendario",
  closeTimeInput: "Chiudi selettore ora",
  collapseRow: "Comprimi riga",
  columnMenu: "Opzioni colonna",
  columnMovedToPosition: (label, position, total) => `${label} spostata in posizione ${position} di ${total}`,
  columns: "Colonne",
  compactPageXOfY: (page, total) => `${page} di ${total}`,
  copied: "Copiato",
  copy: "Copia",
  createOption: (value) => `Crea "${value}"`,
  currentlyPlaying: "in riproduzione",
  currentValue: "Valore attuale",
  date: "Data",
  datePickerKeyboardHelp: "Usa i tasti freccia per modificare i valori; premi Alt+Freccia gi\xF9 per aprire il calendario.",
  day: "Giorno",
  dayPeriod: "AM/PM",
  decrement: "Diminuisci",
  deselectAllRows: "Deseleziona tutte le righe",
  dropFileHere: "Drop file here or click to browse",
  dropFilesHere: "Drop files here or click to browse",
  empty: "Vuoto",
  endDate: "Data di fine",
  enterFullscreen: "Entra in modalit\xE0 a schermo intero",
  error: "Errore",
  exitFullscreen: "Esci dalla modalit\xE0 a schermo intero",
  expandRow: "Espandi riga",
  filterByColumn: (label) => `Filtra per ${label}`,
  filterFrom: "Da",
  filterMax: "Max",
  filterMin: "Min",
  filterTo: "A",
  firstPage: "Prima pagina",
  goToSlide: (slide, count) => `Vai alla diapositiva ${slide} di ${count}`,
  hideColumn: "Nascondi colonna",
  hidePassword: "Nascondi password",
  hour: "Ora",
  incompleteDate: "Inserisci una data valida.",
  increment: "Aumenta",
  jumpBackwardX: (count) => `Indietro di ${count} pagine`,
  jumpForwardX: (count) => `Avanti di ${count} pagine`,
  lastPage: "Ultima pagina",
  loading: "In caricamento",
  minute: "Minuto",
  month: "Mese",
  moreOptions: "Altre opzioni",
  mute: "Disattiva audio",
  nextDecade: "Decennio successivo",
  nextMonth: "Mese successivo",
  nextPage: "Pagina successiva",
  nextSlide: "Prossima diapositiva",
  nextVideo: "Video successivo",
  nextYear: "Anno successivo",
  noData: "Nessun dato",
  noResults: "Nessun risultato corrispondente",
  now: "Adesso",
  numCharacters: (num) => {
    if (num === 1) {
      return "1 carattere";
    }
    return `${num} caratteri`;
  },
  numCharactersRemaining: (num) => {
    if (num === 1) {
      return "1 carattere rimanente";
    }
    return `${num} caratteri rimanenti`;
  },
  numOptionsSelected: (num) => {
    if (num === 0) {
      return "Nessuna opzione selezionata";
    }
    if (num === 1) {
      return "1 opzione selezionata";
    }
    return `${num} opzioni selezionate`;
  },
  numRowsCopied: (num) => num === 1 ? "1 riga copiata" : `${num} righe copiate`,
  numRowsSelected: (num) => num === 1 ? "1 riga selezionata" : `${num} righe selezionate`,
  pageXOfY: (page, total) => `Pagina ${page} di ${total}`,
  pagination: "Impaginazione",
  pause: "Pausa",
  pauseAnimation: "Metti in pausa animazione",
  pictureInPicture: `Immagine nell'immagine`,
  pinLeft: "Fissa a sinistra",
  pinRight: "Fissa a destra",
  play: "Riproduci",
  playAnimation: "Riproduci animazione",
  playbackSpeed: "Velocit\xE0 di riproduzione",
  playlist: "Playlist",
  pm: "PM",
  previousDecade: "Decennio precedente",
  previousMonth: "Mese precedente",
  previousPage: "Pagina precedente",
  previousSlide: "Diapositiva precedente",
  previousVideo: "Video precedente",
  previousYear: "Anno precedente",
  progress: "Avanzamento",
  rangeTooLong: (max) => {
    if (max === 1) {
      return "Seleziona un intervallo non superiore a 1 giorno";
    }
    return `Seleziona un intervallo non superiore a ${max} giorni`;
  },
  rangeTooShort: (min) => {
    if (min === 1) {
      return "Seleziona un intervallo di almeno 1 giorno";
    }
    return `Seleziona un intervallo di almeno ${min} giorni`;
  },
  readonly: "Sola lettura",
  remove: "Rimuovi",
  resetColumns: "Ripristina colonne",
  resize: "Ridimensiona",
  resizeColumn: "Ridimensiona colonna",
  rowsPerPage: "Righe per pagina",
  scrollableRegion: "Area scorrevole",
  scrollToEnd: "Scorri alla fine",
  scrollToStart: "Scorri all'inizio",
  search: "Cerca",
  second: "Secondo",
  seek: "Cerca",
  seekProgress: (current, duration) => `${current} di ${duration}`,
  selectAColorFromTheScreen: "Seleziona un colore dalla schermo",
  selectAllRows: "Seleziona tutte le righe",
  selected: "Selezionato",
  selectedDateLabel: (date) => `Selezionato: ${date}`,
  selectedRangeLabel: (range) => `Intervallo selezionato: ${range}`,
  selectGroup: "Seleziona gruppo",
  selectionCleared: "Selezione cancellata",
  selectRow: "Seleziona riga",
  showingNofMRows: (shown, total) => `Visualizzazione di ${shown} righe su ${total}`,
  showingXtoYofZ: (start, end, total) => `${start}\u2013${end} di ${total}`,
  showPassword: "Mostra password",
  slideNum: (slide) => `Diapositiva ${slide}`,
  sortAscending: "Ordina in modo crescente",
  sortColumn: "Ordina colonna",
  sortDescending: "Ordina in modo decrescente",
  startDate: "Data di inizio",
  time: "Ora",
  timeInputKeyboardHelp: "Usa i tasti freccia per modificare i valori; premi Alt+Freccia gi\xF9 per aprire il selettore ora.",
  today: "Oggi",
  toggleColorFormat: "Cambia formato colore",
  unmute: "Attiva audio",
  unpin: "Sblocca",
  unpinColumn: "Sblocca colonna",
  videoPlayer: "Lettore video",
  volume: "Volume",
  year: "Anno",
  zoomIn: "Ingrandire",
  zoomOut: "Rimpicciolire"
};
registerTranslation(translation);
var it_default = translation;
export {
  it_default as default
};
