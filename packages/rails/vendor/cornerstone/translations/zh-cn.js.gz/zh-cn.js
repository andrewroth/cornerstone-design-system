/*! Cornerstone Components 0.6.2 - MIT licensed. See LICENSE.md and NOTICE. */
import "../chunks/chunk.QUVFD4CZ.js";
import "../chunks/chunk.PRD3XZ4M.js";
import {
  registerTranslation
} from "../chunks/chunk.FFJLVZKJ.js";
import "../chunks/chunk.QQCENPXN.js";

// src/translations/zh-cn.ts
var translation = {
  $code: "zh-cn",
  $name: "\u7B80\u4F53\u4E2D\u6587",
  $dir: "ltr",
  am: "\u4E0A\u5348",
  autosizeColumn: "\u81EA\u9002\u5E94\u5217\u5BBD",
  captions: "\u5B57\u5E55",
  carousel: "\u8DD1\u9A6C\u706F",
  chooseDate: "\u9009\u62E9\u65E5\u671F",
  chooseDecade: "\u9009\u62E9\u5E74\u4EE3",
  chooseMonth: "\u9009\u62E9\u6708\u4EFD",
  chooseTime: "\u9009\u62E9\u65F6\u95F4",
  chooseYear: "\u9009\u62E9\u5E74\u4EFD",
  clearEntry: "\u6E05\u7A7A",
  clearFilter: "\u6E05\u9664\u7B5B\u9009",
  clearSort: "\u6E05\u9664\u6392\u5E8F",
  close: "\u5173\u95ED",
  closeCalendar: "\u5173\u95ED\u65E5\u5386",
  closeTimeInput: "\u5173\u95ED\u65F6\u95F4\u9009\u62E9\u5668",
  collapseRow: "\u6298\u53E0\u884C",
  columnMenu: "\u5217\u9009\u9879",
  columnMovedToPosition: (label, position, total) => `${label} \u5DF2\u79FB\u81F3\u7B2C ${position} \u4E2A\u4F4D\u7F6E\uFF0C\u5171 ${total} \u4E2A`,
  columns: "\u5217",
  compactPageXOfY: (page, total) => `${page} / ${total}`,
  copied: "\u5DF2\u590D\u5236",
  copy: "\u590D\u5236",
  createOption: (value) => `\u521B\u5EFA"${value}"`,
  currentlyPlaying: "\u6B63\u5728\u64AD\u653E",
  currentValue: "\u5F53\u524D\u503C",
  date: "\u65E5\u671F",
  datePickerKeyboardHelp: "\u4F7F\u7528\u65B9\u5411\u952E\u66F4\u6539\u503C\uFF1B\u6309 Alt+\u4E0B\u65B9\u5411\u952E\u6253\u5F00\u65E5\u5386\u3002",
  day: "\u65E5",
  dayPeriod: "\u4E0A\u5348/\u4E0B\u5348",
  decrement: "\u51CF\u5C11",
  deselectAllRows: "\u53D6\u6D88\u9009\u62E9\u6240\u6709\u884C",
  dropFileHere: "Drop file here or click to browse",
  dropFilesHere: "Drop files here or click to browse",
  empty: "\u7A7A",
  endDate: "\u7ED3\u675F\u65E5\u671F",
  enterFullscreen: "\u8FDB\u5165\u5168\u5C4F",
  error: "\u9519\u8BEF",
  exitFullscreen: "\u9000\u51FA\u5168\u5C4F",
  expandRow: "\u5C55\u5F00\u884C",
  filterByColumn: (label) => `\u6309${label}\u7B5B\u9009`,
  filterFrom: "\u5F00\u59CB",
  filterMax: "\u6700\u5927\u503C",
  filterMin: "\u6700\u5C0F\u503C",
  filterTo: "\u7ED3\u675F",
  firstPage: "\u9996\u9875",
  goToSlide: (slide, count) => `\u8F6C\u5230\u7B2C ${slide} \u5F20\u5E7B\u706F\u7247\uFF0C\u5171 ${count} \u5F20`,
  hideColumn: "\u9690\u85CF\u5217",
  hidePassword: "\u9690\u85CF\u5BC6\u7801",
  hour: "\u65F6",
  incompleteDate: "\u8BF7\u8F93\u5165\u6709\u6548\u7684\u65E5\u671F\u3002",
  increment: "\u589E\u52A0",
  jumpBackwardX: (count) => `\u5411\u540E\u8DF3\u8F6C ${count} \u9875`,
  jumpForwardX: (count) => `\u5411\u524D\u8DF3\u8F6C ${count} \u9875`,
  lastPage: "\u672B\u9875",
  loading: "\u52A0\u8F7D\u4E2D",
  minute: "\u5206",
  month: "\u6708",
  moreOptions: "\u66F4\u591A\u9009\u9879",
  mute: "\u9759\u97F3",
  nextDecade: "\u4E0B\u4E00\u4E2A\u5E74\u4EE3",
  nextMonth: "\u4E0B\u4E2A\u6708",
  nextPage: "\u4E0B\u4E00\u9875",
  nextSlide: "\u4E0B\u4E00\u5F20\u5E7B\u706F\u7247",
  nextVideo: "\u4E0B\u4E00\u4E2A\u89C6\u9891",
  nextYear: "\u4E0B\u4E00\u5E74",
  noData: "\u6682\u65E0\u6570\u636E",
  noResults: "\u65E0\u5339\u914D\u7ED3\u679C",
  now: "\u6B64\u523B",
  numCharacters: (num) => `${num}\u4E2A\u5B57\u7B26`,
  numCharactersRemaining: (num) => `\u5269\u4F59${num}\u4E2A\u5B57\u7B26`,
  numOptionsSelected: (num) => {
    if (num === 0) {
      return "\u672A\u9009\u62E9\u4EFB\u4F55\u9879\u76EE";
    }
    if (num === 1) {
      return "\u5DF2\u9009\u62E9 1 \u4E2A\u9879\u76EE";
    }
    return `${num} \u9009\u62E9\u9879\u76EE`;
  },
  numRowsCopied: (num) => `\u5DF2\u590D\u5236 ${num} \u884C`,
  numRowsSelected: (num) => `\u5DF2\u9009\u62E9 ${num} \u884C`,
  pageXOfY: (page, total) => `\u7B2C ${page} \u9875\uFF0C\u5171 ${total} \u9875`,
  pagination: "\u5206\u9875",
  pause: "\u6682\u505C",
  pauseAnimation: "\u6682\u505C\u52A8\u753B",
  pictureInPicture: "\u753B\u4E2D\u753B",
  pinLeft: "\u56FA\u5B9A\u5230\u5DE6\u4FA7",
  pinRight: "\u56FA\u5B9A\u5230\u53F3\u4FA7",
  play: "\u64AD\u653E",
  playAnimation: "\u64AD\u653E\u52A8\u753B",
  playbackSpeed: "\u64AD\u653E\u901F\u5EA6",
  playlist: "\u64AD\u653E\u5217\u8868",
  pm: "\u4E0B\u5348",
  previousDecade: "\u4E0A\u4E00\u4E2A\u5E74\u4EE3",
  previousMonth: "\u4E0A\u4E2A\u6708",
  previousPage: "\u4E0A\u4E00\u9875",
  previousSlide: "\u4E0A\u4E00\u5F20\u5E7B\u706F\u7247",
  previousVideo: "\u4E0A\u4E00\u4E2A\u89C6\u9891",
  previousYear: "\u4E0A\u4E00\u5E74",
  progress: "\u8FDB\u5EA6",
  rangeTooLong: (max) => {
    if (max === 1) {
      return "\u8BF7\u9009\u62E9\u4E0D\u8D85\u8FC7 1 \u5929\u7684\u8303\u56F4";
    }
    return `\u8BF7\u9009\u62E9\u4E0D\u8D85\u8FC7 ${max} \u5929\u7684\u8303\u56F4`;
  },
  rangeTooShort: (min) => {
    if (min === 1) {
      return "\u8BF7\u9009\u62E9\u81F3\u5C11 1 \u5929\u7684\u8303\u56F4";
    }
    return `\u8BF7\u9009\u62E9\u81F3\u5C11 ${min} \u5929\u7684\u8303\u56F4`;
  },
  readonly: "\u53EA\u8BFB",
  remove: "\u5220\u9664",
  resetColumns: "\u91CD\u7F6E\u5217",
  resize: "\u8C03\u6574\u5927\u5C0F",
  resizeColumn: "\u8C03\u6574\u5217\u5BBD",
  rowsPerPage: "\u6BCF\u9875\u884C\u6570",
  scrollableRegion: "\u53EF\u6EDA\u52A8\u533A\u57DF",
  scrollToEnd: "\u6EDA\u52A8\u81F3\u9875\u5C3E",
  scrollToStart: "\u6EDA\u52A8\u81F3\u9875\u9996",
  search: "\u641C\u7D22",
  second: "\u79D2",
  seek: "\u8DF3\u8F6C",
  seekProgress: (current, duration) => `${current} / ${duration}`,
  selectAColorFromTheScreen: "\u4ECE\u5C4F\u5E55\u4E2D\u9009\u62E9\u4E00\u79CD\u989C\u8272",
  selectAllRows: "\u9009\u62E9\u6240\u6709\u884C",
  selected: "\u5DF2\u9009\u62E9",
  selectedDateLabel: (date) => `\u5DF2\u9009\u62E9\uFF1A${date}`,
  selectedRangeLabel: (range) => `\u5DF2\u9009\u62E9\u8303\u56F4\uFF1A${range}`,
  selectGroup: "\u9009\u62E9\u5206\u7EC4",
  selectionCleared: "\u5DF2\u6E05\u9664\u9009\u62E9",
  selectRow: "\u9009\u62E9\u884C",
  showingNofMRows: (shown, total) => `\u663E\u793A ${shown} \u884C\uFF0C\u5171 ${total} \u884C`,
  showingXtoYofZ: (start, end, total) => `${start}\u2013${end}\uFF0C\u5171 ${total} \u9879`,
  showPassword: "\u663E\u793A\u5BC6\u7801",
  slideNum: (slide) => `\u5E7B\u706F\u7247 ${slide}`,
  sortAscending: "\u5347\u5E8F\u6392\u5E8F",
  sortColumn: "\u6392\u5E8F\u5217",
  sortDescending: "\u964D\u5E8F\u6392\u5E8F",
  startDate: "\u5F00\u59CB\u65E5\u671F",
  time: "\u65F6\u95F4",
  timeInputKeyboardHelp: "\u4F7F\u7528\u65B9\u5411\u952E\u66F4\u6539\u503C\uFF1B\u6309 Alt+\u4E0B\u65B9\u5411\u952E\u6253\u5F00\u65F6\u95F4\u9009\u62E9\u5668\u3002",
  today: "\u4ECA\u5929",
  toggleColorFormat: "\u5207\u6362\u989C\u8272\u6A21\u5F0F",
  unmute: "\u53D6\u6D88\u9759\u97F3",
  unpin: "\u53D6\u6D88\u56FA\u5B9A",
  unpinColumn: "\u53D6\u6D88\u56FA\u5B9A\u5217",
  videoPlayer: "\u89C6\u9891\u64AD\u653E\u5668",
  volume: "\u97F3\u91CF",
  year: "\u5E74",
  zoomIn: "\u653E\u5927",
  zoomOut: "\u7F29\u5C0F"
};
registerTranslation(translation);
var zh_cn_default = translation;
export {
  zh_cn_default as default
};
