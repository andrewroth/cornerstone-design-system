/*! Cornerstone Components 0.6.2 - MIT licensed. See LICENSE.md and NOTICE. */
import "../chunks/chunk.QUVFD4CZ.js";
import "../chunks/chunk.PRD3XZ4M.js";
import {
  registerTranslation
} from "../chunks/chunk.FFJLVZKJ.js";
import "../chunks/chunk.QQCENPXN.js";

// src/translations/zh-tw.ts
var translation = {
  $code: "zh-tw",
  $name: "\u6B63\u9AD4\u4E2D\u6587",
  $dir: "ltr",
  am: "\u4E0A\u5348",
  autosizeColumn: "\u81EA\u52D5\u8ABF\u6574\u6B04\u5BEC",
  captions: "\u5B57\u5E55",
  carousel: "\u5E7B\u71C8\u7247",
  chooseDate: "\u9078\u64C7\u65E5\u671F",
  chooseDecade: "\u9078\u64C7\u5E74\u4EE3",
  chooseMonth: "\u9078\u64C7\u6708\u4EFD",
  chooseTime: "\u9078\u64C7\u6642\u9593",
  chooseYear: "\u9078\u64C7\u5E74\u4EFD",
  clearEntry: "\u6E05\u7A7A",
  clearFilter: "\u6E05\u9664\u7BE9\u9078",
  clearSort: "\u6E05\u9664\u6392\u5E8F",
  close: "\u95DC\u9589",
  closeCalendar: "\u95DC\u9589\u65E5\u66C6",
  closeTimeInput: "\u95DC\u9589\u6642\u9593\u9078\u64C7\u5668",
  collapseRow: "\u6536\u5408\u5217",
  columnMenu: "\u6B04\u9078\u9805",
  columnMovedToPosition: (label, position, total) => `${label} \u5DF2\u79FB\u52D5\u81F3\u7B2C ${position} \u500B\u4F4D\u7F6E\uFF0C\u5171 ${total} \u500B`,
  columns: "\u6B04",
  compactPageXOfY: (page, total) => `${page} / ${total}`,
  copied: "\u5DF2\u8907\u88FD",
  copy: "\u8907\u88FD",
  createOption: (value) => `\u5EFA\u7ACB\u300C${value}\u300D`,
  currentlyPlaying: "\u6B63\u5728\u64AD\u653E",
  currentValue: "\u7576\u524D\u503C",
  date: "\u65E5\u671F",
  datePickerKeyboardHelp: "\u4F7F\u7528\u65B9\u5411\u9375\u8B8A\u66F4\u6578\u503C\uFF1B\u6309 Alt+\u4E0B\u65B9\u5411\u9375\u958B\u555F\u65E5\u66C6\u3002",
  day: "\u65E5",
  dayPeriod: "\u4E0A\u5348/\u4E0B\u5348",
  decrement: "\u6E1B\u5C11",
  deselectAllRows: "\u53D6\u6D88\u9078\u64C7\u6240\u6709\u5217",
  dropFileHere: "Drop file here or click to browse",
  dropFilesHere: "Drop files here or click to browse",
  empty: "\u7A7A",
  endDate: "\u7D50\u675F\u65E5\u671F",
  enterFullscreen: "\u9032\u5165\u5168\u87A2\u5E55",
  error: "\u932F\u8AA4",
  exitFullscreen: "\u9000\u51FA\u5168\u87A2\u5E55",
  expandRow: "\u5C55\u958B\u5217",
  filterByColumn: (label) => `\u4F9D${label}\u7BE9\u9078`,
  filterFrom: "\u958B\u59CB",
  filterMax: "\u6700\u5927\u503C",
  filterMin: "\u6700\u5C0F\u503C",
  filterTo: "\u7D50\u675F",
  firstPage: "\u7B2C\u4E00\u9801",
  goToSlide: (slide, count) => `\u8F49\u5230\u7B2C ${slide} \u5F35\u5E7B\u71C8\u7247\uFF0C\u5171 ${count} \u5F35`,
  hideColumn: "\u96B1\u85CF\u6B04",
  hidePassword: "\u96B1\u85CF\u5BC6\u78BC",
  hour: "\u5C0F\u6642",
  incompleteDate: "\u8ACB\u8F38\u5165\u6709\u6548\u7684\u65E5\u671F\u3002",
  increment: "\u589E\u52A0",
  jumpBackwardX: (count) => `\u5411\u524D\u8DF3 ${count} \u9801`,
  jumpForwardX: (count) => `\u5411\u5F8C\u8DF3 ${count} \u9801`,
  lastPage: "\u6700\u5F8C\u4E00\u9801",
  loading: "\u8F09\u5165\u4E2D",
  minute: "\u5206\u9418",
  month: "\u6708",
  moreOptions: "\u66F4\u591A\u9078\u9805",
  mute: "\u975C\u97F3",
  nextDecade: "\u4E0B\u4E00\u500B\u5E74\u4EE3",
  nextMonth: "\u4E0B\u500B\u6708",
  nextPage: "\u4E0B\u4E00\u9801",
  nextSlide: "\u4E0B\u4E00\u5F35\u5E7B\u71C8\u7247",
  nextVideo: "\u4E0B\u4E00\u500B\u5F71\u7247",
  nextYear: "\u4E0B\u4E00\u5E74",
  noData: "\u7121\u8CC7\u6599",
  noResults: "\u7121\u76F8\u7B26\u7684\u7D50\u679C",
  now: "\u73FE\u5728",
  numCharacters: (num) => `${num}\u500B\u5B57\u5143`,
  numCharactersRemaining: (num) => `\u5269\u9918${num}\u500B\u5B57\u5143`,
  numOptionsSelected: (num) => {
    if (num === 0) {
      return "\u672A\u9078\u64C7\u4EFB\u4F55\u9805\u76EE";
    }
    if (num === 1) {
      return "\u5DF2\u9078\u64C7 1 \u500B\u9805\u76EE";
    }
    return `${num} \u9078\u64C7\u9805\u76EE`;
  },
  numRowsCopied: (num) => `\u5DF2\u8907\u88FD ${num} \u5217`,
  numRowsSelected: (num) => `\u5DF2\u9078\u64C7 ${num} \u5217`,
  pageXOfY: (page, total) => `\u7B2C ${page} \u9801\uFF0C\u5171 ${total} \u9801`,
  pagination: "\u5206\u9801",
  pause: "\u66AB\u505C",
  pauseAnimation: "\u66AB\u505C\u52D5\u756B",
  pictureInPicture: "\u5B50\u6BCD\u756B\u9762",
  pinLeft: "\u91D8\u9078\u81F3\u5DE6\u5074",
  pinRight: "\u91D8\u9078\u81F3\u53F3\u5074",
  play: "\u64AD\u653E",
  playAnimation: "\u64AD\u653E\u52D5\u756B",
  playbackSpeed: "\u64AD\u653E\u901F\u5EA6",
  playlist: "\u64AD\u653E\u6E05\u55AE",
  pm: "\u4E0B\u5348",
  previousDecade: "\u4E0A\u4E00\u500B\u5E74\u4EE3",
  previousMonth: "\u4E0A\u500B\u6708",
  previousPage: "\u4E0A\u4E00\u9801",
  previousSlide: "\u4E0A\u4E00\u5F35\u5E7B\u71C8\u7247",
  previousVideo: "\u4E0A\u4E00\u500B\u5F71\u7247",
  previousYear: "\u4E0A\u4E00\u5E74",
  progress: "\u9032\u5EA6",
  rangeTooLong: (max) => {
    if (max === 1) {
      return "\u8ACB\u9078\u64C7\u4E0D\u8D85\u904E 1 \u5929\u7684\u7BC4\u570D";
    }
    return `\u8ACB\u9078\u64C7\u4E0D\u8D85\u904E ${max} \u5929\u7684\u7BC4\u570D`;
  },
  rangeTooShort: (min) => {
    if (min === 1) {
      return "\u8ACB\u9078\u64C7\u81F3\u5C11 1 \u5929\u7684\u7BC4\u570D";
    }
    return `\u8ACB\u9078\u64C7\u81F3\u5C11 ${min} \u5929\u7684\u7BC4\u570D`;
  },
  readonly: "\u552F\u8B80",
  remove: "\u79FB\u9664",
  resetColumns: "\u91CD\u8A2D\u6B04",
  resize: "\u8ABF\u6574\u5927\u5C0F",
  resizeColumn: "\u8ABF\u6574\u6B04\u5BEC",
  rowsPerPage: "\u6BCF\u9801\u5217\u6578",
  scrollableRegion: "\u53EF\u6372\u52D5\u533A\u57DF",
  scrollToEnd: "\u6372\u81F3\u9801\u5C3E",
  scrollToStart: "\u6372\u81F3\u9801\u9996",
  search: "\u641C\u5C0B",
  second: "\u79D2",
  seek: "\u8DF3\u8F49",
  seekProgress: (current, duration) => `${current} / ${duration}`,
  selectAColorFromTheScreen: "\u5F9E\u87A2\u5E55\u4E2D\u9078\u64C7\u4E00\u7A2E\u984F\u8272",
  selectAllRows: "\u9078\u64C7\u6240\u6709\u5217",
  selected: "\u5DF2\u9078\u64C7",
  selectedDateLabel: (date) => `\u5DF2\u9078\u64C7\uFF1A${date}`,
  selectedRangeLabel: (range) => `\u5DF2\u9078\u64C7\u7BC4\u570D\uFF1A${range}`,
  selectGroup: "\u9078\u64C7\u7FA4\u7D44",
  selectionCleared: "\u5DF2\u6E05\u9664\u9078\u64C7",
  selectRow: "\u9078\u64C7\u5217",
  showingNofMRows: (shown, total) => `\u986F\u793A ${shown} \u5217\uFF0C\u5171 ${total} \u5217`,
  showingXtoYofZ: (start, end, total) => `${start}\u2013${end}\uFF0C\u5171 ${total}`,
  showPassword: "\u986F\u793A\u5BC6\u78BC",
  slideNum: (slide) => `\u5E7B\u71C8\u7247 ${slide}`,
  sortAscending: "\u5347\u51AA\u6392\u5E8F",
  sortColumn: "\u6392\u5E8F\u6B04",
  sortDescending: "\u964D\u51AA\u6392\u5E8F",
  startDate: "\u958B\u59CB\u65E5\u671F",
  time: "\u6642\u9593",
  timeInputKeyboardHelp: "\u4F7F\u7528\u65B9\u5411\u9375\u8B8A\u66F4\u6578\u503C\uFF1B\u6309 Alt+\u4E0B\u65B9\u5411\u9375\u958B\u555F\u6642\u9593\u9078\u64C7\u5668\u3002",
  today: "\u4ECA\u5929",
  toggleColorFormat: "\u5207\u63DB\u984F\u8272\u683C\u5F0F",
  unmute: "\u53D6\u6D88\u975C\u97F3",
  unpin: "\u53D6\u6D88\u91D8\u9078",
  unpinColumn: "\u53D6\u6D88\u91D8\u9078\u6B04",
  videoPlayer: "\u5F71\u7247\u64AD\u653E\u5668",
  volume: "\u97F3\u91CF",
  year: "\u5E74",
  zoomIn: "\u653E\u5927",
  zoomOut: "\u7E2E\u5C0F"
};
registerTranslation(translation);
var zh_tw_default = translation;
export {
  zh_tw_default as default
};
